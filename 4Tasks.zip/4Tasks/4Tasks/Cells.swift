//
//  ListCell.swift
//  4Tasks
//
//  Created by MingyuFan on 3/26/17.
//  Copyright © 2017 MingyuFan. All rights reserved.
//

import UIKit

class ListCell: UITableViewCell {
    @IBOutlet var TaskName: UILabel!
    
}

class GridCellZero: UITableViewCell {
    @IBOutlet var TaskName: UILabel!
    
}

class GridCellOne: UITableViewCell {
    @IBOutlet var TaskName: UILabel!
    
}

class GridCellTwo: UITableViewCell {
    @IBOutlet var TaskName: UILabel!
    
}

class GridCellThree: UITableViewCell {
    @IBOutlet var TaskName: UILabel!
    
}

